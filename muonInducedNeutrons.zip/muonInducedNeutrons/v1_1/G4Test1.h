#include "TG4DetectorConstruction.h"
#include "TG4ActionInitialization.h"
#include "TG4UIsession.h"

#include <iostream>
#include <ctime>

#include <TFile.h>

#ifdef G4MULTITHREADED
#include "G4MTRunManager.hh"
#else
#include "G4RunManager.hh"
#endif

#include "G4UImanager.hh"

#include "G4VisExecutive.hh"
#include "G4UIExecutive.hh"

#include "Randomize.hh"

#include "G4PhysListFactory.hh"


