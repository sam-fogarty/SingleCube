Building this code requires a few things (see CMakeLists.txt):
-It is assumed this code will be built on a linux machine
-CMake
-ROOT
-Geant4

The main program here is named:
G4Test1.cc

To build the code:
1.) Copy the project to where you want the source directory to be, let's call this PRJDIR
2.) There are a couple of user defined variables that need to be set relative to PRJDIR, the file and variable name are each listed.

G4Test1.cc
	sourceDir needs set in int main(int argc,char** argv)

TG4GPSPrimaryGeneratorAction.cc
	inFile.open() needs set in void G4::TG4GPSPrimaryGeneratorAction::SetEnergyHist()

3.) clean_build.sh and clean_logs.sh can be used to clean the build and logs, respectively

4.) enter the build directory
$ cd PRJDIR/build

5.) Use CMake
$ cmake ../

6.) build the code
$ make

7.) execute the project
$ ./G4Test1

8.) fire some muons using the Geant4 UI
/run/beamOn 1000


