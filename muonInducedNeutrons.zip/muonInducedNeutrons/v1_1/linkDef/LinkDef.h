#ifdef __ROOTCLING__
//#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;
#pragma link C++ nestedclasses;
//#pragma link C++ nestedclass;
#pragma link C++ nestedtypedef;
#pragma link C++ all typedef;
//ABOVE HERE IS THE STANDARD PREAMBLE
//SEE(https://root.cern.ch/selecting-dictionary-entries-linkdefh)

#pragma link C++ class D2ESim::G4::TG4Recoil+;

#endif
