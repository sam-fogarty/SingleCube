#include "TG4RunAction.h"
using namespace D2ESim;

//-------------------------------------------------------------------//
G4::TG4RunAction::TG4RunAction():
	G4UserRunAction(),
	fOutputFile(NULL)
{

}
//-------------------------------------------------------------------//
G4::TG4RunAction::~TG4RunAction(){
	//clean fTrackContainer
	for(D2ESim::G4::TG4RunAction::TrackIterator_t iter = fTrackContainer.begin();
		iter != fTrackContainer.end(); ++iter){
		if( (*iter) != NULL){
			delete (*iter);
			(*iter) = NULL;
		}
	}
	fTrackContainer.clear();
}
//-------------------------------------------------------------------//
void G4::TG4RunAction::BeginOfRunAction(const G4Run*){
	cout << "...D2ESim::G4::TG4RunAction::BeginOfRuNAction()" << endl;
	cout << "......run started" << endl;
	if(fTrackContainer.empty() != true){
		fTrackContainer.clear();
	}
	if(fNeutronTrackIDs.empty() != true){
		fNeutronTrackIDs.clear();
	}
	if(fRecoilContainer.empty() != true){
		for(D2ESim::G4::TG4RunAction::G4RecoilContainerIterator_t iter = fRecoilContainer.begin();
			iter != fRecoilContainer.end(); ++iter){
			delete (*iter);
		}
		fRecoilContainer.clear();
	}

	//fNumMuons = 0;
	fNumNeutrons = 0;
}
//-------------------------------------------------------------------//
void G4::TG4RunAction::EndOfRunAction(const G4Run* run){
	//PrintTrackInfo();
	PrintNeutrons();
	PrintRecoils();
	//WriteNeutrons();
	WriteRecoils();
	cout << "...D2ESim::G4::TG4RunAction::EndOfRunAction()" << endl;

	//Note these numbers must match those shown in TG4DetectorConstruction
	Double_t targetDensity = 8.03;//[g/cm^3]
	Double_t targetZLength = 1.5;//[cm]
	//Double_t targetDensity = 1.0;//[g/cm^3]
	//Double_t targetZLength = 250.0;//[cm]
	Double_t yield = Double_t(fNumNeutrons)/( Double_t(run->GetNumberOfEvent())*targetDensity*targetZLength );
	cout << "......targetDensity = " << targetDensity << " [g/cm^3]" << endl;
	cout << "......targetZLength = " << targetZLength << " [cm] " << endl;
	cout << "......numMuons = " << run->GetNumberOfEvent() << endl;
	cout << "......numNeutrons = " << fNumNeutrons << endl;
	cout << "......yield = " << yield << " [ neutrons/( muon*g/cm^2 ) ]" << endl;

	cout << "......number of Events = " << run->GetNumberOfEvent() << endl;
	cout << "......run complete" << endl;
}
//-------------------------------------------------------------------//
void G4::TG4RunAction::AddTrack(const G4Track* track){
	//new
	G4Track* trackNew = new G4Track(*track);
	fTrackContainer.push_back(trackNew);

	//old
	//fTrackContainer.push_back(track);
}
//-------------------------------------------------------------------//
void G4::TG4RunAction::PrintTrackInfo(){
	//G4int ii=0;

	for(D2ESim::G4::TG4RunAction::TrackIterator_t iter = fTrackContainer.begin();
		iter != fTrackContainer.end(); ++iter){
		//ii += 1;
		G4cout << "...D2ESim::G4::TG4RunAction::PrintTrackInfo()" << G4endl;
		//G4cout << "......Track = " << ii << G4endl;
		G4cout << "......TrackID = " << (*iter)->GetTrackID() << G4endl;
		G4cout << "......TrackLength = " << (*iter)->GetTrackLength() << endl;
		//G4cout << "......LogicalVolume = " << (*iter)->GetLogicalVolumeAtVertex()->GetName() << G4endl;
		G4cout << "......ParentID = " << (*iter)->GetParentID() << G4endl;
		//G4cout << "......InitialKineticEnergy = " << (*iter)->GetVertexKineticEnergy() << G4endl;
		//G4cout << "......InitialMomentumDirection = (" << 
		//	(*iter)->GetVertexMomentumDirection().getX() << "," <<  
		//	(*iter)->GetVertexMomentumDirection().getY() << "," <<
		//	(*iter)->GetVertexMomentumDirection().getX() << ")" << G4endl;
		//G4cout << "......InitialPosition = (" << 
		//	(*iter)->GetVertexPosition().getX() << "," <<  
		//	(*iter)->GetVertexPosition().getY() << "," <<
		//	(*iter)->GetVertexPosition().getX() << ")" << G4endl;
		G4cout << "......ParticleName = " << (*iter)->GetParticleDefinition()->GetParticleName() << G4endl;
		//G4cout << "......ProcessName = " << (*iter)->GetCreatorProcess()->GetProcessName() << G4endl;
		//G4cout << "......ModelName = " << (*iter)->GetCreatorModelName() << G4endl;
	}

}
//-------------------------------------------------------------------//
void G4::TG4RunAction::AddNeutronTrackID(G4int trackID){
	fNeutronTrackIDs.push_back(Int_t(trackID));
}
//-------------------------------------------------------------------//
void G4::TG4RunAction::AddRecoil(D2ESim::G4::TG4Recoil* recoil){
	fRecoilContainer.push_back(recoil);
}
//-------------------------------------------------------------------//
void G4::TG4RunAction::SetOutputFile(TFile* outputFile){
	fOutputFile = new TFile();
	fOutputFile = outputFile;
}
//-------------------------------------------------------------------//
void G4::TG4RunAction::WriteNeutrons(){
	if(fOutputFile == NULL){
		G4cerr << "...D2ESim::G4::TG4RunAction::WriteNeutrons()" << G4endl;
		G4cerr << "......ERROR: fOutputFile has not been set" << G4endl;
		exit(-1);
	}

	/*for(D2ESim::G4::TG4RunAction::G4NeutronTrackIDIterator_t iter = fNeutronTrackIDs.begin();
		iter != fNeutronTrackIDs.end(); ++iter){
	}*/
	//write neutron trackIDs to file
	//fNeutronTrackIDs->Write();//option 1

	//std::string name = "fNeutronTrackIDS";//option2
	//fOutputFile->WriteTObject(fNeutronTrackIDs,name.c_str());

}
//-------------------------------------------------------------------//
void G4::TG4RunAction::WriteRecoils(){
	/*if(fOutputFile == NULL){
		G4cerr << "...D2ESim::G4::TG4RunAction::WriteRecoils()" << G4endl;
		G4cerr << "......ERROR: fOutputFile has not been set" << G4endl;
		exit(-1);
	}*/

	//write recoils to file
	for(D2ESim::G4::TG4RunAction::G4RecoilContainerIterator_t iter = fRecoilContainer.begin();
		iter != fRecoilContainer.end(); ++iter){
		(*iter)->Write();
		//fOutputFile->WriteTObject((*iter));
	}
}
//-------------------------------------------------------------------//
void G4::TG4RunAction::PrintNeutrons(){
	G4cout << "...D2ESim::G4::TG4RunAction::PrintNeutrons()" << G4endl;
	for(D2ESim::G4::TG4RunAction::G4NeutronTrackIDIterator_t iter = fNeutronTrackIDs.begin();
		iter != fNeutronTrackIDs.end(); ++iter){
		G4cout << "......TrackID = " << (*iter) << G4endl;
	}
}
//-------------------------------------------------------------------//
void G4::TG4RunAction::PrintRecoils(){
	G4cout << "...D2ESim::G4::TG4RunAction::PrintRecoils()" << G4endl;
	for(D2ESim::G4::TG4RunAction::G4RecoilContainerIterator_t iter = fRecoilContainer.begin();
		iter != fRecoilContainer.end(); ++iter){
		(*iter)->PrintInfo();
	}
}
//-------------------------------------------------------------------//
/*void G4::TG4RunAction::IncrementNumMuons(){
	fNumMuons += 1;
}*/
//-------------------------------------------------------------------//
void G4::TG4RunAction::IncrementNumNeutrons(){
	fNumNeutrons += 1;
}
//-------------------------------------------------------------------//




