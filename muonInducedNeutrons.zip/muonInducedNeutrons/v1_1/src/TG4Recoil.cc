#include "TG4Recoil.h"
using namespace D2ESim;
ClassImp(G4::TG4Recoil)

//-------------------------------------------------------------------//
G4::TG4Recoil::TG4Recoil(){

}
//-------------------------------------------------------------------//
G4::TG4Recoil::~TG4Recoil(){

}
//-------------------------------------------------------------------//
void G4::TG4Recoil::SetTrackID(G4int trackID){
	fTrackID = Int_t(trackID);
}
//-------------------------------------------------------------------//
void G4::TG4Recoil::SetParentID(G4int parentID){
	fParentID = Int_t(parentID);
}
//-------------------------------------------------------------------//
void G4::TG4Recoil::SetParticleName(G4String particleName){
	fParticleName = TObjString(particleName.data());
}
//-------------------------------------------------------------------//
void G4::TG4Recoil::SetCreatorProcess(G4String creatorProcess){
	fCreatorProcess = TObjString(creatorProcess.data());
}
//-------------------------------------------------------------------//
void G4::TG4Recoil::SetParticleMass(G4double particleMass){
	fParticleMass = Double_t(particleMass);
}
//-------------------------------------------------------------------//
void G4::TG4Recoil::SetKineticEnergy(G4double kineticEnergy){
	fKineticEnergy = Double_t(kineticEnergy);
}
//-------------------------------------------------------------------//
void G4::TG4Recoil::SetPosition(G4ThreeVector position){
	Double_t xPos = Double_t(position.getX());
	Double_t yPos = Double_t(position.getY());
	Double_t zPos = Double_t(position.getZ());
	fPosition.SetXYZ(xPos,yPos,zPos);
}
//-------------------------------------------------------------------//
void G4::TG4Recoil::SetMomentumDirection(G4ThreeVector momentumDirection){
	Double_t xMom = Double_t(momentumDirection.getX());
	Double_t yMom = Double_t(momentumDirection.getY());
	Double_t zMom = Double_t(momentumDirection.getZ());
	fMomentumDirection.SetXYZ(xMom,yMom,zMom);
}
//-------------------------------------------------------------------//
void G4::TG4Recoil::PrintInfo(){
	G4cout << "...D2ESim::G4::TG4Recoil::PrintInfo()" << G4endl;
	G4cout << "......TrackID = " << fTrackID << G4endl;
	G4cout << "......ParentID = " << fParentID << G4endl;
	G4cout << "......ParticleName = " << G4String(fParticleName.GetName()) << G4endl;
	G4cout << "......CreatorProcess = " << G4String(fCreatorProcess.GetName()) << G4endl;
	G4cout << "......ParticleMass = " << fParticleMass << " MeV/c^2" << G4endl;
	G4cout << "......KineticEnergy = " << fKineticEnergy << " MeV" << G4endl;
	G4cout << "......Position = (" << fPosition.X() << "," << fPosition.Y() << 
	"," << fPosition.Z() << ")" << " mm" << G4endl;
	G4cout << "......MomentumDirection = (" << fMomentumDirection.X() << "," 
	<< fMomentumDirection.Y() << "," << fMomentumDirection.Z() << ")" << G4endl;
}
//-------------------------------------------------------------------//
Int_t G4::TG4Recoil::GetTrackID(){
	return fTrackID;
}
//-------------------------------------------------------------------//
Int_t G4::TG4Recoil::GetParentID(){
	return fParentID;
}
//-------------------------------------------------------------------//
TString G4::TG4Recoil::GetParticleName(){
	return fParticleName.GetString();
}
//-------------------------------------------------------------------//
TString G4::TG4Recoil::GetCreatorProcess(){
	return fCreatorProcess.GetString();
}
//-------------------------------------------------------------------//
Double_t G4::TG4Recoil::GetParticleMass(){
	return fParticleMass;
}
//-------------------------------------------------------------------//
Double_t G4::TG4Recoil::GetKineticEnergy(){
	return fKineticEnergy;
}
//-------------------------------------------------------------------//
TVector3 G4::TG4Recoil::GetPosition(){
	return fPosition;
}
//-------------------------------------------------------------------//
TVector3 G4::TG4Recoil::GetMomentumDirection(){
	return fMomentumDirection;
}
//-------------------------------------------------------------------//



