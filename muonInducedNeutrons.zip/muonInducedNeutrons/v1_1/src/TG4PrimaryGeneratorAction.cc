#include "TG4PrimaryGeneratorAction.h"
using namespace D2ESim;

//-------------------------------------------------------------------//
G4::TG4PrimaryGeneratorAction::TG4PrimaryGeneratorAction():
	fParticleGun(NULL)
{
	G4int n_particle = 1;
	fParticleGun  = new G4ParticleGun(n_particle);
	G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
	G4String particleName;
	//G4ParticleDefinition* particle
		//= particleTable->FindParticle(particleName="neutron");
	G4ParticleDefinition* particle
		= particleTable->FindParticle(particleName="mu-");
	fParticleGun->SetParticleDefinition(particle);
	fParticleGun->SetParticleMomentumDirection(G4ThreeVector(0.,0.,1.));
	//fParticleGun->SetParticleEnergy(3.*MeV);
	fParticleGun->SetParticleEnergy(10000.*MeV);
}
//-------------------------------------------------------------------//
G4::TG4PrimaryGeneratorAction::~TG4PrimaryGeneratorAction(){
	delete fParticleGun;
}
//-------------------------------------------------------------------//
void G4::TG4PrimaryGeneratorAction::GeneratePrimaries(G4Event* event){
	G4double x0 = 0.0;
	G4double y0 = 0.0;
	G4double z0 = -100.0*cm;
	//G4double z0 = -130.0*cm;
	fParticleGun->SetParticlePosition(G4ThreeVector(x0,y0,z0));
	fParticleGun->GeneratePrimaryVertex(event);
}
//-------------------------------------------------------------------//
G4ParticleGun* G4::TG4PrimaryGeneratorAction::GetParticleGun(){
	return fParticleGun;
}
//-------------------------------------------------------------------//



