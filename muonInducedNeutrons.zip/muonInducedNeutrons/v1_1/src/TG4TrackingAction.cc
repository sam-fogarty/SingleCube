#include "TG4TrackingAction.h"
using namespace D2ESim;

//-------------------------------------------------------------------//
G4::TG4TrackingAction::TG4TrackingAction(D2ESim::G4::TG4RunAction* runAction):
	G4UserTrackingAction(),
	fRunAction(runAction)
{

}
//-------------------------------------------------------------------//
G4::TG4TrackingAction::~TG4TrackingAction(){

}
//-------------------------------------------------------------------//
void G4::TG4TrackingAction::PreUserTrackingAction(const G4Track* track){
	//static int ii=0; //Debug
	/*if( track->GetParticleDefinition()->GetParticleName() != G4String("e-") && 
		track->GetParticleDefinition()->GetParticleName() != G4String("e+") &&
		track->GetParticleDefinition()->GetParticleName() != G4String("gamma")){
		cout << "...******************************" << endl;
		cout << "...TrackID = " << track->GetTrackID() << endl;
		cout << "...TrackLength = " << track->GetTrackLength() << endl;
		cout << "...ParentID = " << track->GetParentID() << endl;
		cout << "...LogicalVolume = " << track->GetLogicalVolumeAtVertex()->GetName() << endl;
		cout << "...ParticleName = " << track->GetParticleDefinition()->GetParticleName() << endl;
		cout << "...KineticEnergy = " << track->GetKineticEnergy() << " MeV" << endl;
	}*/


	/*if( track->GetParticleDefinition()->GetParticleName() == G4String("mu-") ){
		cout << "...******************************" << endl;
		cout << "...TrackID = " << track->GetTrackID() << endl;
		cout << "...TrackLength = " << track->GetTrackLength() << endl;
		cout << "...ParentID = " << track->GetParentID() << endl;
		cout << "...LogicalVolume = " << track->GetLogicalVolumeAtVertex()->GetName() << endl;
		cout << "...ParticleName = " << track->GetParticleDefinition()->GetParticleName() << endl;
		cout << "...KineticEnergy = " << track->GetKineticEnergy() << " MeV" << endl;
	}*/
	/*if( track->GetParticleDefinition()->GetParticleName() == G4String("neutron") ){
		cout << "...******************************" << endl;
		cout << "...TrackID = " << track->GetTrackID() << endl;
		cout << "...TrackLength = " << track->GetTrackLength() << endl;
		cout << "...ParentID = " << track->GetParentID() << endl;

		//Note we can use this, if the neutron track starts in the target and ends after the
		//target it is of interest
		cout << "...LogicalVolume = " << track->GetLogicalVolumeAtVertex()->GetName() << endl;

		cout << "...ParticleName = " << track->GetParticleDefinition()->GetParticleName() << endl;
		//cout << "...CreatorProcess = " << track->GetCreatorProcess()->GetProcessName() << endl;
	}*/


/*
		if( track->GetParticleDefinition()->GetParticleName() == G4String("neutron") ){
			G4cout << "...******************************" << G4endl;
			//G4cout << "...Track = " << ii << G4endl;
			G4cout << "...TrackID = " << track->GetTrackID() << G4endl;
			G4cout << "...TrackLength = " << track->GetTrackLength() << G4endl;
			G4cout << "...ParentID = " << track->GetParentID() << G4endl;
			//cout << "...LogicalVolume = " << track->GetLogicalVolumeAtVertex()->GetName() << endl;
			G4cout << "...ParticleName = " << track->GetParticleDefinition()->GetParticleName() << G4endl;
			//G4cout << "...CreatorProcess = " << track->GetCreatorProcess()->GetProcessName() << G4endl;
		}
*/

/*
	//if( track->GetLogicalVolumeAtVertex()->GetName() == G4String("GasLogicalVolume") ){
		if( track->GetParticleDefinition()->GetParticleName() == G4String("C12") ||
			track->GetParticleDefinition()->GetParticleName() == G4String("C13") ||
			track->GetParticleDefinition()->GetParticleName() == G4String("S32") ||
			track->GetParticleDefinition()->GetParticleName() == G4String("S33") ||
			track->GetParticleDefinition()->GetParticleName() == G4String("S34") ||
			track->GetParticleDefinition()->GetParticleName() == G4String("S36") ){
			AddTrackToRun(track);
			//ii = ii + 1;
			G4cout << "...******************************" << G4endl;
			//G4cout << "...Track = " << ii << G4endl;
			G4cout << "...TrackID = " << track->GetTrackID() << G4endl;
			G4cout << "...TrackLength = " << track->GetTrackLength() << G4endl;
			G4cout << "...ParentID = " << track->GetParentID() << G4endl;
			//cout << "...LogicalVolume = " << track->GetLogicalVolumeAtVertex()->GetName() << endl;
			G4cout << "...ParticleName = " << track->GetParticleDefinition()->GetParticleName() << G4endl;
			//G4cout << "...CreatorProcess = " << track->GetCreatorProcess()->GetProcessName() << G4endl;
		}
	//}
*/

	if( track->GetParticleDefinition()->GetParticleName() == G4String("neutron") ){
		fRunAction->AddNeutronTrackID(track->GetTrackID());
	}


	/*if( track->GetLogicalVolumeAtVertex()->GetName() == G4String("GasLogicalVolume") ){
		if( track->GetParticleDefinition()->GetParticleName() == G4String("C12") ||
		track->GetParticleDefinition()->GetParticleName() == G4String("C13") ||
		track->GetParticleDefinition()->GetParticleName() == G4String("S32") ||
		track->GetParticleDefinition()->GetParticleName() == G4String("S33") ||
		track->GetParticleDefinition()->GetParticleName() == G4String("S34") ||
		track->GetParticleDefinition()->GetParticleName() == G4String("S36") ){
			D2ESim::G4::TG4Recoil* recoil = new D2ESim::G4::TG4Recoil();
			recoil->SetTrackID(track->GetTrackID());
			recoil->SetParentID(track->GetParentID());
			recoil->SetParticleName(track->GetParticleDefinition()->GetParticleName());
			recoil->SetCreatorProcess(track->GetCreatorProcess()->GetProcessName());
			recoil->SetParticleMass(track->GetParticleDefinition()->GetPDGMass());
			recoil->SetKineticEnergy(track->GetVertexKineticEnergy());//compare to GetKineticEnergy()
			recoil->SetPosition(track->GetVertexPosition());//G4ThreeVector
			recoil->SetMomentumDirection(track->GetVertexMomentumDirection());//G4ThreeVector
			fRunAction->AddRecoil(recoil);
		}
	}*/

}
//-------------------------------------------------------------------//
void G4::TG4TrackingAction::PostUserTrackingAction(const G4Track* track){

	Double_t zPastTarget = 7.5; //mm
	//Double_t zPastTarget = 1250.0; //mm

	if( track->GetParticleDefinition()->GetParticleName() == G4String("neutron") &&
		track->GetVolume()->GetName() == G4String("WorldPhysical") &&
		track->GetPosition().getZ() > zPastTarget){
		/*cout << "...******************************" << endl;
		cout << "...TrackID = " << track->GetTrackID() << endl;
		cout << "...TrackLength = " << track->GetTrackLength() << endl;
		cout << "...ParentID = " << track->GetParentID() << endl;

		//Note we can use this, if the neutron track starts in the target and ends after the
		//target it is of interest
		cout << "...LogicalVolume = " << track->GetLogicalVolumeAtVertex()->GetName() << endl;
		cout << "...PhysicalVolume = " << track->GetVolume()->GetName() << endl;
		cout << "...xPosition = " << track->GetPosition().getX() << " mm" << endl;
		cout << "...yPosition = " << track->GetPosition().getY() << " mm" << endl;
		cout << "...zPosition = " << track->GetPosition().getZ() << " mm" << endl;
		cout << "...ParticleName = " << track->GetParticleDefinition()->GetParticleName() << endl;
		//cout << "...CreatorProcess = " << track->GetCreatorProcess()->GetProcessName() << endl;
		*/
		fRunAction->IncrementNumNeutrons();
	}

/*
		if( track->GetParticleDefinition()->GetParticleName() == G4String("neutron") ){
			G4cout << "...******************************" << G4endl;
			G4cout << "...TrackID = " << track->GetTrackID() << G4endl;
			G4cout << "...TrackLength = " << track->GetTrackLength() << G4endl;
			G4cout << "...ParentID = " << track->GetParentID() << G4endl;
			//cout << "...LogicalVolume = " << track->GetLogicalVolumeAtVertex()->GetName() << endl;
			G4cout << "...ParticleName = " << track->GetParticleDefinition()->GetParticleName() << G4endl;
			//G4cout << "...CreatorProcess = " << track->GetCreatorProcess()->GetProcessName() << G4endl;
		}
*/

/*
	//if( track->GetLogicalVolumeAtVertex()->GetName() == G4String("GasLogicalVolume") ){
		if( track->GetParticleDefinition()->GetParticleName() == G4String("C12") ||
			track->GetParticleDefinition()->GetParticleName() == G4String("C13") ||
			track->GetParticleDefinition()->GetParticleName() == G4String("S32") ||
			track->GetParticleDefinition()->GetParticleName() == G4String("S33") ||
			track->GetParticleDefinition()->GetParticleName() == G4String("S34") ||
			track->GetParticleDefinition()->GetParticleName() == G4String("S36") ){
			AddTrackToRun(track);
			//ii = ii + 1;
			G4cout << "...******************************" << G4endl;
			//G4cout << "...Track = " << ii << G4endl;
			G4cout << "...TrackID = " << track->GetTrackID() << G4endl;
			G4cout << "...TrackLength = " << track->GetTrackLength() << G4endl;
			G4cout << "...ParentID = " << track->GetParentID() << G4endl;
			//cout << "...LogicalVolume = " << track->GetLogicalVolumeAtVertex()->GetName() << endl;
			G4cout << "...ParticleName = " << track->GetParticleDefinition()->GetParticleName() << G4endl;
			//G4cout << "...CreatorProcess = " << track->GetCreatorProcess()->GetProcessName() << G4endl;
		}
	//}
*/

}
//-------------------------------------------------------------------//
void G4::TG4TrackingAction::AddTrackToRun(const G4Track* track){
	fRunAction->AddTrack(track);
}
//-------------------------------------------------------------------//
