#include "TG4UIsession.h"
using namespace D2ESim;

//-------------------------------------------------------------------//
G4::TG4UIsession::TG4UIsession():
	//G4UIsession()
	fG4coutFileName(""),
	fG4cerrFileName(""),
	fG4coutFile(NULL),
	fG4cerrFile(NULL)
{

}
//-------------------------------------------------------------------//
G4::TG4UIsession::~TG4UIsession(){
	if(fG4coutFile != NULL){
		//fG4coutFile->close();
		CloseG4coutFile();
		delete fG4coutFile;
	}
	if(fG4cerrFile != NULL){
		//fG4cerrFile->close();
		CloseG4cerrFile();
		delete fG4cerrFile;
	}
}
//-------------------------------------------------------------------//
G4int G4::TG4UIsession::ReceiveG4cout(const G4String& coutString) {
	std::string temp = std::string(coutString.data());
	*fG4coutFile << temp << endl;
	return 0;
}
//-------------------------------------------------------------------//
G4int G4::TG4UIsession::ReceiveG4cerr(const G4String& cerrString) {
	std::string temp = std::string(cerrString.data());
	*fG4cerrFile << temp << endl;
	return 0;
}
//-------------------------------------------------------------------//
void G4::TG4UIsession::SetG4coutFileName(std::string fileName){
	fG4coutFileName = fileName;
}
//-------------------------------------------------------------------//
void G4::TG4UIsession::SetG4cerrFileName(std::string fileName){
	fG4cerrFileName = fileName;
}
//-------------------------------------------------------------------//
void G4::TG4UIsession::OpenG4coutFile(){
	if( fG4coutFileName != "" ){
		fG4coutFile = new std::ofstream();
		fG4coutFile->open(fG4coutFileName.c_str(),ios::app);
		*fG4coutFile << "************************************************************" << endl;
		*fG4coutFile << "************************************************************" << endl;
		*fG4coutFile << "************************************************************" << endl;
	}
	else{
		exit(-1);
	}
}
//-------------------------------------------------------------------//
void G4::TG4UIsession::OpenG4cerrFile(){
	if( fG4cerrFileName != "" ){
		fG4cerrFile = new std::ofstream();
		fG4cerrFile->open(fG4cerrFileName.c_str(),ios::app);
		*fG4cerrFile << "************************************************************" << endl;
		*fG4cerrFile << "************************************************************" << endl;
		*fG4cerrFile << "************************************************************" << endl;
	}
	else{
		exit(-1);
	}
}
//-------------------------------------------------------------------//
void G4::TG4UIsession::CloseG4coutFile(){
	fG4coutFile->close();
}
//-------------------------------------------------------------------//
void G4::TG4UIsession::CloseG4cerrFile(){
	fG4cerrFile->close();
}
//-------------------------------------------------------------------//



