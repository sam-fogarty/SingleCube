#include "TG4GPSPrimaryGeneratorAction.h"
using namespace D2ESim;

//-------------------------------------------------------------------//
G4::TG4GPSPrimaryGeneratorAction::TG4GPSPrimaryGeneratorAction():
	fParticleSource(NULL)
{

	fParticleSource  = new G4GeneralParticleSource();

	G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
	G4String particleName;
	G4ParticleDefinition* particle
		= particleTable->FindParticle(particleName="neutron");
	fParticleSource->SetParticleDefinition(particle);
	fParticleSource->GetCurrentSource()->GetPosDist()->SetPosDisType("Point");
	G4double xPos = 0.0*cm;
	G4double yPos = 0.0*cm;
	G4double zPos = -100.0*cm;
	G4ThreeVector pos = G4ThreeVector(xPos,yPos,zPos);
	fParticleSource->GetCurrentSource()->GetPosDist()->SetCentreCoords(pos);
	fParticleSource->GetCurrentSource()->GetAngDist()->SetAngDistType("iso");
	fParticleSource->GetCurrentSource()->GetEneDist()->SetEnergyDisType("User");
	SetEnergyHist();
	//fParticleSource->GetCurrentSource()->GetEneDist()->InputEnergySpectra(true);
	G4int n_particle = 1;
	fParticleSource->SetNumberOfParticles(n_particle);
	fParticleSource->SetVerbosity(2);
	//fParticleSource->SetCurrentSourceIntensity();

}
//-------------------------------------------------------------------//
G4::TG4GPSPrimaryGeneratorAction::~TG4GPSPrimaryGeneratorAction(){
	delete fParticleSource;
}
//-------------------------------------------------------------------//
void G4::TG4GPSPrimaryGeneratorAction::GeneratePrimaries(G4Event* event){


	fParticleSource->GeneratePrimaryVertex(event);
}
//-------------------------------------------------------------------//
G4GeneralParticleSource* G4::TG4GPSPrimaryGeneratorAction::GetParticleSource(){
	return fParticleSource;
}
//-------------------------------------------------------------------//
void G4::TG4GPSPrimaryGeneratorAction::SetEnergyHist(){
	fstream inFile;
	//inFile.open("/home/fred/Research/driftIIe/RecoilsMC/test/geant2/G4macros/Cf252pdf.txt");
	inFile.open("/home/fred/Research/SamF/muonInducedNeutrons/v1_1/G4macros/Cf252pdf.txt");
	G4double eHigh;
	G4double weight;
	if(inFile.is_open()){
		while(inFile.good()){
			inFile >> eHigh >> weight;
			fParticleSource->GetCurrentSource()->GetEneDist()->UserEnergyHisto(G4ThreeVector(eHigh,weight,0));
		}
	}
}
//-------------------------------------------------------------------//



