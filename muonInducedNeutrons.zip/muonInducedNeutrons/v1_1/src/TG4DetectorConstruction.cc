#include "TG4DetectorConstruction.h"
using namespace D2ESim;

//-------------------------------------------------------------------//
G4::TG4DetectorConstruction::TG4DetectorConstruction():
	fWorldSolid(NULL),
	fWorldLogicalVolume(NULL),
	fWorldPhysicalVolume(NULL),
	fMaterial_Air(NULL),
	fTargetSolid(NULL),
	fTargetLogicalVolume(NULL),
	fTargetPhysicalVolume(NULL),
	fMaterial_SS304(NULL)
	//fVesselSolid(NULL),
	//fVesselLogicalVolume(NULL),
	//fVesselPhysicalVolume(NULL),
	//fMaterial_SS304(NULL),
	//fGas(NULL),
	//fGasLogicalVolume(NULL),
	//fGasPhysicalVolume(NULL),
	//fMaterial_CS2Gas(NULL)
{

}
//-------------------------------------------------------------------//
G4::TG4DetectorConstruction::~TG4DetectorConstruction(){

}
//-------------------------------------------------------------------//
void G4::TG4DetectorConstruction::ConstructLab(){

	G4NistManager* nistMan = G4NistManager::Instance();
	G4bool checkOverlaps = true;

	G4double sizeX = 10*m;
	G4double sizeY = 10*m;
	G4double sizeZ = 10*m;
	//fMaterial_Air = nistMan->FindOrBuildMaterial("G4_AIR");
	fMaterial_Air = nistMan->FindOrBuildMaterial("G4_Galactic");//vacuum of space
	fWorldSolid = new G4Box("WorldSolid", 0.5*sizeX, 0.5*sizeY, 0.5*sizeZ);
	fWorldLogicalVolume = new G4LogicalVolume(
		fWorldSolid,     //its solid
		fMaterial_Air,   //its material
		"WorldLogical"          //its name
	);
	fWorldPhysicalVolume = new G4PVPlacement(
		0,                          //its rotation
		G4ThreeVector(),            //its position
		fWorldLogicalVolume,        //it logical volume
		"WorldPhysical",           //its name
		0,                          //its mother volume
		false,                      //its boolean operation
		0,                          //its copy number
		checkOverlaps               //enable overlaps checking
	);

}
//-------------------------------------------------------------------//
void G4::TG4DetectorConstruction::ConstructTarget(){

	G4NistManager* nistMan = G4NistManager::Instance();
	G4bool checkOverlaps = true;

	//Contruct 304 Stainless Steel
	G4Element* element_Fe = nistMan->FindOrBuildElement("Fe");
	G4Element* element_Cr = nistMan->FindOrBuildElement("Cr");
	G4Element* element_Ni = nistMan->FindOrBuildElement("Ni");
	G4Element* element_C = nistMan->FindOrBuildElement("C");
	G4Element* element_Mn = nistMan->FindOrBuildElement("Mn");
	G4Element* element_P = nistMan->FindOrBuildElement("P");
	G4Element* element_S = nistMan->FindOrBuildElement("S");
	G4Element* element_Si = nistMan->FindOrBuildElement("Si");
	G4Element* element_N = nistMan->FindOrBuildElement("N");
	G4String name = "material_SS304";
	G4double density = 8.03*g/cm3; //density of 304 grade stainless steel
	//G4double density = 100.0*g/cm3; //increased density to make things happen
	G4int ncomponents = 9; //number of elements in 304 grade stainless steel
	fMaterial_SS304 = new G4Material(name,density,ncomponents,kStateSolid);
	fMaterial_SS304->AddElement(element_Fe,68.0*perCent);
	fMaterial_SS304->AddElement(element_Cr,19.0*perCent);
	fMaterial_SS304->AddElement(element_Ni,10.0*perCent);
	fMaterial_SS304->AddElement(element_C,0.08*perCent);
	fMaterial_SS304->AddElement(element_Mn,2.0*perCent);
	fMaterial_SS304->AddElement(element_P,0.04*perCent);
	fMaterial_SS304->AddElement(element_S,0.03*perCent);
	fMaterial_SS304->AddElement(element_Si,0.75*perCent);
	fMaterial_SS304->AddElement(element_N,0.1*perCent);
	//Change target to water
	//fMaterial_SS304 = nistMan->FindOrBuildMaterial("G4_WATER");

	G4double sizeX = 50*cm;
	G4double sizeY = 50*cm;
	G4double sizeZ = 1.5*cm;
	//G4double sizeZ = 250*cm;
	G4ThreeVector posTarget = G4ThreeVector(0, 0, 0);
	fTargetSolid = new G4Box("TargetSolid", 0.5*sizeX, 0.5*sizeY, 0.5*sizeZ);
	fTargetLogicalVolume = new G4LogicalVolume(
		fTargetSolid,     //its solid
		fMaterial_SS304,   //its material
		"TargetLogicalVolume"          //its name
	);
	fTargetPhysicalVolume = new G4PVPlacement(
		0,                          //its rotation
		posTarget,            //its position
		fTargetLogicalVolume,        //it logical volume
		"TargetPhysicalVolume",           //its name
		fWorldLogicalVolume,                          //its mother volume
		false,                      //its boolean operation
		0,                          //its copy number
		checkOverlaps               //enable overlaps checking
	);

}
//-------------------------------------------------------------------//
/*void G4::TG4DetectorConstruction::ConstructVessel(){

	G4NistManager* nistMan = G4NistManager::Instance();
	G4bool checkOverlaps = true;

	G4Element* element_Fe = nistMan->FindOrBuildElement("Fe");
	G4Element* element_Cr = nistMan->FindOrBuildElement("Cr");
	G4Element* element_Ni = nistMan->FindOrBuildElement("Ni");
	G4Element* element_C = nistMan->FindOrBuildElement("C");
	G4Element* element_Mn = nistMan->FindOrBuildElement("Mn");
	G4Element* element_P = nistMan->FindOrBuildElement("P");
	G4Element* element_S = nistMan->FindOrBuildElement("S");
	G4Element* element_Si = nistMan->FindOrBuildElement("Si");
	G4Element* element_N = nistMan->FindOrBuildElement("N");

	G4String name = "material_SS304";
	G4double density = 8.03*g/cm3; //density of 304 grade stainless steel
	G4int ncomponents = 9; //number of elements in 304 grade stainless steel
	fMaterial_SS304 = new G4Material(name,density,ncomponents,kStateSolid);
	fMaterial_SS304->AddElement(element_Fe,68.0*perCent);
	fMaterial_SS304->AddElement(element_Cr,19.0*perCent);
	fMaterial_SS304->AddElement(element_Ni,10.0*perCent);
	fMaterial_SS304->AddElement(element_C,0.08*perCent);
	fMaterial_SS304->AddElement(element_Mn,2.0*perCent);
	fMaterial_SS304->AddElement(element_P,0.04*perCent);
	fMaterial_SS304->AddElement(element_S,0.03*perCent);
	fMaterial_SS304->AddElement(element_Si,0.75*perCent);
	fMaterial_SS304->AddElement(element_N,0.1*perCent);

	G4double v1SizeX = 1514*mm, v1SizeY = 1514*mm, v1SizeZ = 1514*mm;
	G4Box* v1 = new G4Box("v1", 0.5*v1SizeX, 0.5*v1SizeY, 0.5*v1SizeZ);
	G4double v2SizeX = 1500*mm, v2SizeY = 1500*mm, v2SizeZ = 1500*mm;
	G4Box* v2 = new G4Box("v2", 0.5*v2SizeX, 0.5*v2SizeY, 0.5*v2SizeZ);
	fVesselSolid = new G4SubtractionSolid("VesselSolid",v1,v2);
	G4ThreeVector posVessel = G4ThreeVector(0, 0, 0);
	fVesselLogicalVolume = new G4LogicalVolume(
		fVesselSolid,
		fMaterial_SS304,
		"VesselLogicalVolume"
	);
	fVesselPhysicalVolume = new G4PVPlacement(
		0,
		posVessel,
		fVesselLogicalVolume,
		"VesselPhysicalVolume",
		fWorldLogicalVolume,
		false,
		0,
		checkOverlaps
	);
}
*/
//-------------------------------------------------------------------//
/*void G4::TG4DetectorConstruction::ConstructGas(){

	G4NistManager* nistMan = G4NistManager::Instance();
	G4bool checkOverlaps = true;

	G4Element* element_C = nistMan->FindOrBuildElement("C");
	G4Element* element_S = nistMan->FindOrBuildElement("S");


//	//Use this code to list which isotopes of each element are available
//	cout << "...CARBON ISOTOPES" << endl;
//	for(G4IsotopeVector::iterator iter = element_C->GetIsotopeVector()->begin();
//		iter != element_C->GetIsotopeVector()->end(); ++iter){
//		cout << "......" << (*iter)->GetName() << endl;
//	}
//	cout << "...SULFUR ISOTOPES" << endl;
//	for(G4IsotopeVector::iterator iter = element_S->GetIsotopeVector()->begin();
//		iter != element_S->GetIsotopeVector()->end(); ++iter){
//		cout << "......" << (*iter)->GetName() << endl;
//	}
	//Note the above results in these isotopes being available:
	//These are the stable isotopes
	//C12,C13
	//S32,S33,S34,S36


	//for testing
	//G4double density = 10.0*g/cm3;
	//G4double pressure = 3160000.0*atmosphere;

	G4double density = 0.167*mg/cm3;
	G4double pressure = 40.0*atmosphere/760.0; // 40 Torr
	G4double temperature = 293.0*kelvin;
	G4int ncomponents = 2;
	G4int natoms = 0;
	G4String name = "material_CS2Gas";

	fMaterial_CS2Gas = new G4Material(
		name,
		density,
		ncomponents,
		kStateGas,
		temperature,
		pressure
	);
	fMaterial_CS2Gas->AddElement(element_C, natoms=1);
	fMaterial_CS2Gas->AddElement(element_S, natoms=2);

	G4double gasSizeX = 1500*mm, gasSizeY = 1500*mm, gasSizeZ = 1500*mm;
	//G4double gasSizeX = 1514*mm, gasSizeY = 1514*mm, gasSizeZ = 1514*mm; //BBB
	fGas = new G4Box("Gas", 0.5*gasSizeX, 0.5*gasSizeY, 0.5*gasSizeZ);
	fGasLogicalVolume = new G4LogicalVolume(
		fGas,
		fMaterial_CS2Gas,
		"GasLogicalVolume"
	);
	G4ThreeVector posGas = G4ThreeVector(0, 0, 0);
	fGasPhysicalVolume = new G4PVPlacement(
		0,
		posGas,
		fGasLogicalVolume,
		"GasPhysicalVolume",
		fWorldLogicalVolume,
		false,
		0,
		checkOverlaps
	);
}
*/
//-------------------------------------------------------------------//
G4VPhysicalVolume* G4::TG4DetectorConstruction::Construct(){

	//WARNING: These private members must be called in the order below,
	//changing the order may cause errors.
	ConstructLab();
	ConstructTarget();
	//ConstructVessel();
	//ConstructGas();

	return fWorldPhysicalVolume;
}
//-------------------------------------------------------------------//



