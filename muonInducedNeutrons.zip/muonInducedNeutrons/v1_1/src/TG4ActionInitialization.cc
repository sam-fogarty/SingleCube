#include "TG4ActionInitialization.h"
using namespace D2ESim;

//-------------------------------------------------------------------//
G4::TG4ActionInitialization::TG4ActionInitialization():
	G4VUserActionInitialization(),
	fOutFile(NULL)
{

}
//-------------------------------------------------------------------//
G4::TG4ActionInitialization::TG4ActionInitialization(TFile* outFile):
	G4VUserActionInitialization(),
	fOutFile(NULL)
{
	fOutFile = new TFile();
	fOutFile = outFile;
}
//-------------------------------------------------------------------//
G4::TG4ActionInitialization::~TG4ActionInitialization(){

}
//-------------------------------------------------------------------//
void G4::TG4ActionInitialization::BuildForMaster() const {
	
}
//-------------------------------------------------------------------//
void G4::TG4ActionInitialization::Build() const {
	SetUserAction(new G4::TG4PrimaryGeneratorAction());//particle gun
	//SetUserAction(new G4::TG4GPSPrimaryGeneratorAction());//general particle source (GPS)

	D2ESim::G4::TG4RunAction* runAction = new D2ESim::G4::TG4RunAction;

	if(fOutFile != NULL){
		runAction->SetOutputFile(fOutFile);
	}

	SetUserAction(runAction);

	D2ESim::G4::TG4TrackingAction* trackingAction = new D2ESim::G4::TG4TrackingAction(runAction);
	SetUserAction(trackingAction);
}
//-------------------------------------------------------------------//

