#ifndef _TG4PrimaryGeneratorAction_h_
#define _TG4PrimaryGeneratorAction_h_

//**************************************************
//UserDefined
//**************************************************
//C++
//**************************************************
//ROOT
//**************************************************
//Geant4
#include "G4VUserPrimaryGeneratorAction.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"
#include "globals.hh"
//**************************************************

using namespace std;

namespace D2ESim{
namespace G4{


class TG4PrimaryGeneratorAction: public G4VUserPrimaryGeneratorAction {
	public:
		TG4PrimaryGeneratorAction();
		virtual ~TG4PrimaryGeneratorAction();

		virtual void GeneratePrimaries(G4Event* event);

		G4ParticleGun* GetParticleGun();

	private:
		G4ParticleGun* fParticleGun;

	//ClassDef(TG4PrimaryGeneratorAction,1);
};

}//namespace G4
}//namespace D2ESim

#endif //_TG4PrimaryGeneratorAction_h_



