#ifndef _TG4ActionInitialization_h_
#define _TG4ActionInitialization_h_

//**************************************************
//UserDefined
#include "TG4PrimaryGeneratorAction.h"
#include "TG4GPSPrimaryGeneratorAction.h"
#include "TG4RunAction.h"
#include "TG4TrackingAction.h"
//**************************************************
//C++
//**************************************************
//ROOT
#include <TFile.h>
//**************************************************
//Geant4
#include "G4VUserActionInitialization.hh"
//**************************************************

using namespace std;

namespace D2ESim{
namespace G4{


class TG4ActionInitialization: public G4VUserActionInitialization {
	public:
		TG4ActionInitialization();
		TG4ActionInitialization(TFile* outFile);
		virtual ~TG4ActionInitialization();

		virtual void BuildForMaster() const;
		virtual void Build() const;

	private:
		TFile* fOutFile;
	//ClassDef(TG4ActionInitialization,1);
};

}//namespace G4
}//namespace D2ESim

#endif //_TG4ActionInitialization_h_



