#ifndef _TG4GPSPrimaryGeneratorAction_h_
#define _TG4GPSPrimaryGeneratorAction_h_

//**************************************************
//UserDefined
//**************************************************
//C++
#include <fstream>
//**************************************************
//ROOT
//**************************************************
//Geant4
#include "G4VUserPrimaryGeneratorAction.hh"
#include "G4GeneralParticleSource.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"
#include "globals.hh"

//#include "G4GeneralParticleSourceData.hh"
//#include "G4SingleParticleSource.hh"
//#include "G4SPSPosDistribution.hh"
//#include "G4SPSAngDistribution.hh"
//#include "G4SPSEneDistribution.hh"
//**************************************************

using namespace std;

namespace D2ESim{
namespace G4{


class TG4GPSPrimaryGeneratorAction: public G4VUserPrimaryGeneratorAction {
	public:
		TG4GPSPrimaryGeneratorAction();
		virtual ~TG4GPSPrimaryGeneratorAction();

		virtual void GeneratePrimaries(G4Event* event);

		G4GeneralParticleSource* GetParticleSource();
		void SetEnergyHist();

	private:
		G4GeneralParticleSource* fParticleSource;

	//ClassDef(TG4GPSPrimaryGeneratorAction,1);
};

}//namespace G4
}//namespace D2ESim

#endif //_TG4GPSPrimaryGeneratorAction_h_



