#ifndef _TG4UIsession_h_
#define _TG4UIsession_h_

//**************************************************
//UserDefined
//**************************************************
//C++
//#include <iostream>
#include <fstream>
//**************************************************
//ROOT
//**************************************************
//Geant4
#include "G4UIsession.hh"
//**************************************************

using namespace std;

namespace D2ESim{
namespace G4{


class TG4UIsession: public G4UIsession {
	public:
		TG4UIsession();
		virtual ~TG4UIsession();

	G4int ReceiveG4cout(const G4String& coutString);
	G4int ReceiveG4cerr(const G4String& cerrString);

	void SetG4coutFileName(std::string fileName);
	void SetG4cerrFileName(std::string fileName);
	void OpenG4coutFile();
	void OpenG4cerrFile();
	void CloseG4coutFile();
	void CloseG4cerrFile();

	private:
	std::string fG4coutFileName;
	std::string fG4cerrFileName;
	ofstream* fG4coutFile;
	ofstream* fG4cerrFile;

	//ClassDef(TG4UIsession,1);
};

}//namespace G4
}//namespace D2ESim

#endif //_TG4UIsession_h_



