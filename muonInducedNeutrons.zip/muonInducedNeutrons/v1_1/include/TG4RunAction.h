#ifndef _TG4RunAction_h_
#define _TG4RunAction_h_

//**************************************************
//UserDefined
#include "TG4Recoil.h"
//**************************************************
//C++
//**************************************************
//ROOT
#include "TROOT.h"
#include "TFile.h"
//**************************************************
//Geant4
#include "G4UserRunAction.hh"
#include "G4Run.hh"
#include "globals.hh"
#include "G4Track.hh"
#include "G4VProcess.hh"
//**************************************************

using namespace std;

namespace D2ESim{
namespace G4{


class TG4RunAction: public G4UserRunAction {
	public:
		typedef std::vector<const G4Track*> G4TrackContainer_t;
		typedef G4TrackContainer_t::iterator TrackIterator_t;
		//typedef G4TrackContainer_t::const_iterator TrackIterator_t;

		typedef std::vector<Int_t> G4NeutronTrackIDs_t;
		typedef G4NeutronTrackIDs_t::iterator G4NeutronTrackIDIterator_t;
		typedef std::vector<D2ESim::G4::TG4Recoil*> G4RecoilContainer_t;
		typedef G4RecoilContainer_t::iterator G4RecoilContainerIterator_t;

		TG4RunAction();
		virtual ~TG4RunAction();

	// virtual G4Run* GenerateRun();
	virtual void BeginOfRunAction(const G4Run*);
	//virtual void EndOfRunAction(const G4Run*);
	virtual void EndOfRunAction(const G4Run* run);

	void AddTrack(const G4Track* track);
	void PrintTrackInfo();

	void AddNeutronTrackID(G4int trackID);
	void AddRecoil(D2ESim::G4::TG4Recoil* recoil);
	void SetOutputFile(TFile* outputFile);
	void WriteNeutrons();//write to TFile
	void WriteRecoils();//write to TFile;
	void PrintNeutrons();
	void PrintRecoils();

	//void IncrementNumMuons();
	void IncrementNumNeutrons();

	private:
		G4TrackContainer_t fTrackContainer;
		G4NeutronTrackIDs_t fNeutronTrackIDs;
		G4RecoilContainer_t fRecoilContainer;
		TFile* fOutputFile;

		//UInt_t fNumMuons;
		UInt_t fNumNeutrons;

	//ClassDef(TG4RunAction,1);
};

}//namespace G4
}//namespace D2ESim

#endif //_TG4RunAction_h_

/*
	for(D2ESim::G4::TG4RunAction::TrackIterator_t iter = fTrackContainer.begin();
		iter != fTrackContainer.end(); ++iter){
		//(*iter)->Stuff();
	}
*/



