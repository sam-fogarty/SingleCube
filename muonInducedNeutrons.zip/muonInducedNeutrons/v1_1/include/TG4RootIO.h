#ifndef _TG4RootIO_h_
#define _TG4RootIO_h_

//**************************************************
//UserDefined
#include "TG4RunAction.h"
//**************************************************
//C++
//**************************************************
//ROOT
#include <TFile.h>
//**************************************************
//Geant4
#include "globals.hh"
//**************************************************

using namespace std;

namespace D2ESim{
namespace G4{


class TG4RootIO{
	public:
		TG4RootIO(D2ESim::G4::TG4RunAction* runAction);
		~TG4RootIO();

		void SetRunOutputFile(TFile* file);

	private:
		D2ESim::G4::TG4RunAction* fRunAction;
	//ClassDef(TG4RootIO,1);
};

}//namespace G4
}//namespace D2ESim

#endif //_TG4RootIO_h_



