#ifndef _TG4TrackingAction_h_
#define _TG4TrackingAction_h_

//**************************************************
//UserDefined
#include "TG4RunAction.h"
#include "TG4Recoil.h"
//**************************************************
//C++
//**************************************************
//ROOT
//**************************************************
//Geant4
#include "G4UserTrackingAction.hh"
#include "G4Track.hh"
#include "globals.hh"
//**************************************************

using namespace std;

namespace D2ESim{
namespace G4{


class TG4TrackingAction: public G4UserTrackingAction {
	public:
		TG4TrackingAction(D2ESim::G4::TG4RunAction* runAction);
		virtual ~TG4TrackingAction();

	virtual void PreUserTrackingAction(const G4Track*);
	virtual void PostUserTrackingAction(const G4Track*);

	void AddTrackToRun(const G4Track* track);

	private:
		D2ESim::G4::TG4RunAction* fRunAction;
	//ClassDef(TG4TrackingAction,1);
};

}//namespace G4
}//namespace D2ESim

#endif //_TG4TrackingAction_h_



