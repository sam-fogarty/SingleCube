#ifndef _TG4DetectorConstruction_h_
#define _TG4DetectorConstruction_h_

//**************************************************
//UserDefined
//**************************************************
//C++
//**************************************************
//ROOT
//**************************************************
//Geant4
#include "globals.hh"
#include "G4SystemOfUnits.hh"
#include "G4VUserDetectorConstruction.hh"
#include "G4VPhysicalVolume.hh"
#include "G4LogicalVolume.hh"
#include "G4Box.hh"
#include "G4NistManager.hh"
#include "G4Element.hh"
#include "G4Material.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4VisAttributes.hh"
#include "G4SubtractionSolid.hh"
#include "G4IsotopeVector.hh"
#include "G4Isotope.hh"
using namespace std;

//-------------------------------------------------------------------//
namespace D2ESim{
namespace G4{


class TG4DetectorConstruction: public G4VUserDetectorConstruction {
	public:
		TG4DetectorConstruction();
		~TG4DetectorConstruction();

		G4VPhysicalVolume* Construct();

		//void SetVOI();
		//?* GetVOI();



	private:
		void ConstructLab();
		void ConstructTarget();
		//void ConstructVessel();
		//void ConstructGas();

	private:
		G4Box* fWorldSolid;
		G4LogicalVolume* fWorldLogicalVolume;
		G4PVPlacement* fWorldPhysicalVolume;
		G4Material* fMaterial_Air;

		G4Box* fTargetSolid;
		G4LogicalVolume* fTargetLogicalVolume;
		G4PVPlacement* fTargetPhysicalVolume;
		G4Material* fMaterial_SS304;

		//G4SubtractionSolid* fVesselSolid;
		//G4LogicalVolume* fVesselLogicalVolume;
		//G4PVPlacement* fVesselPhysicalVolume;
		//G4Material* fMaterial_SS304;

		//G4Box* fGas;
		//G4LogicalVolume* fGasLogicalVolume;
		//G4PVPlacement* fGasPhysicalVolume;
		//G4Material* fMaterial_CS2Gas;

		//* fVOI //VOI --> Volume of Interest

	//ClassDef(TG4DetectorConstruction,1);
};

}//namespace G4
}//namespace D2ESim
//-------------------------------------------------------------------//

#endif //_TG4DetectorConstruction_h_



