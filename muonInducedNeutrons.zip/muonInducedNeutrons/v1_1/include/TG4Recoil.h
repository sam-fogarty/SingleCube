#ifndef _TG4Recoil_h_
#define _TG4Recoil_h_

//The idea is to accept GEANT4 data types and then convert to
//ROOT data types to save to file. I do not believe things need to
//be done this way, this is just what I have chosen to do. One may
//be able to wrtie GEANT4 data types to TFile. One can also inheret
//from the G4VHit class, which I may want to do in the next iteration
//of this code, I am not sure if this might provide some advantages.

//To be able to load this class with ROOT interactively, use this in the shell
//gSystem->Load("/home/fred/Research/driftIIe/RecoilsMC/test/geant2/build/libG4RECOIL_LIB.so");

//**************************************************
//UserDefined
//**************************************************
//C++
#include <vector>
#include <string>
//#include <cmath>
//#include <iostream>
//**************************************************
//ROOT
#include <TROOT.h>
#include <TObject.h>
#include <TFile.h>
#include <TVector3.h>
#include <TObjString.h>
#include <TString.h>
//**************************************************
//Geant4
#include "globals.hh"
#include "G4ThreeVector.hh"
//**************************************************

using namespace std;

namespace D2ESim{
namespace G4{


class TG4Recoil: public TObject {
	public:
		TG4Recoil();
		~TG4Recoil();

		void SetTrackID(G4int trackID);
		void SetParentID(G4int parentID);
		void SetParticleName(G4String particleName);
		void SetCreatorProcess(G4String creatorProcess);
		void SetParticleMass(G4double particleMass);
		void SetKineticEnergy(G4double kineticEnergy);
		void SetPosition(G4ThreeVector position);
		void SetMomentumDirection(G4ThreeVector momentumDirection);
		void PrintInfo();

		Int_t GetTrackID();
		Int_t GetParentID();
		TString GetParticleName();
		TString GetCreatorProcess();
		Double_t GetParticleMass();
		Double_t GetKineticEnergy();
		TVector3 GetPosition();
		TVector3 GetMomentumDirection();

	private:
	//Note: //!  --> do not write to file
			//|| --> store contiguously (vectors, containters, ...)
		Int_t fTrackID;
		Int_t fParentID;
		TObjString fParticleName;
		TObjString fCreatorProcess;
		Double_t fParticleMass;//[MeV/c^2]
		Double_t fKineticEnergy;//[MeV]
		TVector3 fPosition;//[mm]
		TVector3 fMomentumDirection;//a unit vector

	ClassDef(TG4Recoil,1);
};

}//namespace G4
}//namespace D2ESim

#endif //_TG4Recoil_h_



