#include "G4Test1.h"

//-------------------------------------------------------------------//
int main(int argc,char** argv)
{
	//Let's Set the Source Directory (USER NEEDS TO SET THIS)
	std::string sourceDir = "/home/fred/Research/SamF/muonInducedNeutrons/v1_1";

	// Detect interactive mode (if no arguments) and define UI session
	G4UIExecutive* ui = 0;
	if ( argc == 1 ) {
		ui = new G4UIExecutive(argc, argv);
	}

	// Choose the Random engine
	G4Random::setTheEngine(new CLHEP::RanecuEngine);

	// Construct the default run manager
	//
	#ifdef G4MULTITHREADED
		G4MTRunManager* runManager = new G4MTRunManager;
	#else
		G4RunManager* runManager = new G4RunManager;
	#endif

	// Detector construction
	runManager->SetUserInitialization(new D2ESim::G4::TG4DetectorConstruction());

	// Physics list
	G4int verbose = 1;
	G4PhysListFactory factory;
	//G4VModularPhysicsList* physlist = factory.GetReferencePhysList("FTFP_BERT_HP");
	G4VModularPhysicsList* physlist = factory.GetReferencePhysList("QGSP_BERT_HP");
	physlist->SetVerboseLevel(verbose);
	runManager->SetUserInitialization(physlist);

	std::string outputDir = sourceDir + "/output/";
	std::string outputFileName = "G4Test1_output_1.root";
	TFile* outputFile = new TFile((outputDir+outputFileName).c_str(),"recreate");
	//runManager->GetUserRunAction()->SetOutputFile(outputFile);

	// User action initialization
	runManager->SetUserInitialization(new D2ESim::G4::TG4ActionInitialization());
	//runManager->SetUserInitialization(new D2ESim::G4::TG4ActionInitialization(outputFile));

	//original code
	G4VisManager* visManager = new G4VisExecutive;
	// G4VisExecutive can take a verbosity argument - see /vis/verbose guidance.
	// G4VisManager* visManager = new G4VisExecutive("Quiet");
	visManager->Initialize();


	// Get the pointer to the User Interface manager
	G4UImanager* UImanager = G4UImanager::GetUIpointer();

	// construct a session which receives G4cout/G4cerr
	D2ESim::G4::TG4UIsession* LoggedSession = new D2ESim::G4::TG4UIsession();
	LoggedSession->SetG4coutFileName(sourceDir + "/G4coutLog.txt");
	LoggedSession->OpenG4coutFile();
	LoggedSession->SetG4cerrFileName(sourceDir + "/G4cerrLog.txt");
	LoggedSession->OpenG4cerrFile();
	UImanager->SetCoutDestination(LoggedSession);
	//Let's print the current date and time to the log file
	//Local time
	time_t tNow = time(0);
	char* tNowChar = ctime(&tNow);
	G4cout << "...Start of GEANT4 session: " << tNowChar << " [Local Time (Colorado, USA)]" << G4endl;
	G4cout << "...Running" << G4endl;
	//UTC time
	//tm* tGMT = gmtime(&tNow)
	//char* tGMTChar = asctime(tGMT);

	// Process macro or start UI session
	//
	if ( ! ui ) { 
		// batch mode
		G4String command = "/control/execute ";
		G4String fileName = argv[1];
		UImanager->ApplyCommand(command+fileName);
	}
	else { 
		// interactive mode
		UImanager->ApplyCommand("/control/execute init_vis.mac");
		ui->SessionStart();
		delete ui;
	}

	outputFile->Close();
	delete outputFile;

	// Job termination
	// Free the store: user actions, physics_list and detector_description are
	// owned and deleted by the run manager, so they should not be deleted 
	// in the main() program !
	delete LoggedSession;
	delete visManager;
	delete runManager;
}
//-------------------------------------------------------------------//



