#completely clean the build
#!/bin/bash

echo "*******************************"
echo "...Cleaning the build directory"
echo "*******************************"

rm -r build
mkdir build