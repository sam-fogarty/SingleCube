#completely clean the build
#!/bin/bash

echo "*******************************"
echo "...Cleaning the logs"
echo "*******************************"

rm G4coutLog.txt
rm G4cerrLog.txt

printf '\n' > G4coutLog.txt
printf '\n' > G4cerrLog.txt
