//Before using this script, first enter these lines into the root shell

/*
gSystem->Load("/home/fred/Research/BDX/simulation/muonInducedNeutrons/v1_1/build/libG4RECOIL_LIB.so");
UInt_t fNumRecoils;
UInt_t fCurrentRecoilNum = 0;
TFile* fFile = new TFile();
D2ESim::G4::TG4Recoil* fRecoil = new D2ESim::G4::TG4Recoil();
*/


void UpdateFile(const char* fileName){
	if(fFile != NULL){
		delete fFile;
		fFile = NULL;
	}

	fFile = new TFile(fileName);

	//extract the number of recoils
	TIter next(fFile->GetListOfKeys());
	TKey* key;
	TString classTypeCompare = "D2ESim::G4::TG4Recoil";
	fNumRecoils = 0;
	while( (key = (TKey*)next()) ){
		TString classType = TString(key->GetClassName());
		if(classType == classTypeCompare){
			fNumRecoils += 1;
		}
	}
	fCurrentRecoilNum = 0;

	cout << "...UpdateFile()" << endl;
	cout << "......fNumRecoils = " << fNumRecoils << endl;
}

void LoadRecoil(UInt_t recoilNum){
	if(fRecoil != NULL){
		delete fRecoil;
		fRecoil = NULL;
	}

	fRecoil = new D2ESim::G4::TG4Recoil();
	std::string recoilName = "D2ESim::G4::TG4Recoil;" + std::to_string(recoilNum);
	fFile->GetObject(recoilName.c_str(),fRecoil);
}

//LoadRecoil() must first be called
void PrintRecoil(){
	if(fRecoil == NULL){
		cout << "...PrintRecoil()" << endl;
		cout << "......ERROR: fRecoil has not been set" << endl;
		exit(-1);
	}

	fRecoil->PrintInfo();
}

